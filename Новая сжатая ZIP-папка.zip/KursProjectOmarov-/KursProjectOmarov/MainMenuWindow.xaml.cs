﻿using System.Collections.Generic;
using System.Windows;

namespace KursProjectOmarov
{
    public partial class MainMenuWindow : Window
    {
        public MainMenuWindow()
        {
            InitializeComponent();
            LoadEnsembles();
        }

        private void LoadEnsembles()
        {
            // Пример списка ансамблей
            var ensembles = new List<string> { "Ансамбль 1", "Ансамбль 2", "Ансамбль 3" };
            EnsembleListBox.ItemsSource = ensembles;
        }

        private void ShowCompositionCount_Click(object sender, RoutedEventArgs e)
        {
            if (EnsembleListBox.SelectedItem is string ensembleName)
            {
                int count = DatabaseHelper.GetCompositionCount(ensembleName);
                MessageBox.Show($"Количество музыкальных произведений ансамбля '{ensembleName}': {count}");
            }
            else
            {
                MessageBox.Show("Выберите ансамбль из списка.");
            }
        }

        private void ShowCDTitles_Click(object sender, RoutedEventArgs e)
        {
            if (EnsembleListBox.SelectedItem is string ensembleName)
            {
                List<string> cdTitles = DatabaseHelper.GetCDTitles(ensembleName);
                MessageBox.Show($"Диски ансамбля '{ensembleName}':\n{string.Join("\n", cdTitles)}");
            }
            else
            {
                MessageBox.Show("Выберите ансамбль из списка.");
            }
        }

        private void ShowBestsellers_Click(object sender, RoutedEventArgs e)
        {
            List<string> bestsellers = DatabaseHelper.GetBestsellers();
            MessageBox.Show($"Лидеры продаж текущего года:\n{string.Join("\n", bestsellers)}");
        }

        private void ExitButton_Click(object sender, RoutedEventArgs e)
        {
            Close();
        }
    }
}
