﻿using System.Windows;

namespace KursProjectOmarov
{
    public partial class AddEnsembleWindow : Window
    {
        public AddEnsembleWindow()
        {
            InitializeComponent();
        }

        private void SaveButton_Click(object sender, RoutedEventArgs e)
        {
            string ensembleName = EnsembleNameTextBox.Text;
            MessageBox.Show($"Ансамбль {ensembleName} сохранен.");
        }
    }
}
