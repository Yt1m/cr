﻿using System;
using System.Windows;

namespace KursProjectOmarov
{
    public partial class AuthorizationWindow : Window
    {
        public AuthorizationWindow()
        {
            InitializeComponent();
        }

        // Обработчик для кнопки "Войти"
        private void LoginButton_Click(object sender, RoutedEventArgs e)
        {
            string username = TextBoxName.Text;
            string password = PasswordBox.Password;

            // Логика проверки логина и пароля
            if (username == "1" && password == "1")
            {
                MessageBox.Show("Авторизация успешна!");
                // Открытие основного окна
                MainMenuWindow mainMenu = new MainMenuWindow();
                mainMenu.Show();
                this.Close(); // Закрытие окна авторизации
            }
            else
            {
                MessageBox.Show("Неверный логин или пароль.");
            }
        }
    }
}
