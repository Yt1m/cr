﻿using System.Windows;  // Добавьте эту директиву

namespace KursProjectOmarov
{
    public partial class App : Application
    {
        // Убедитесь, что здесь нет метода Main. 
        // Он не нужен, так как используется StartupUri для указания начального окна.
    }
}
