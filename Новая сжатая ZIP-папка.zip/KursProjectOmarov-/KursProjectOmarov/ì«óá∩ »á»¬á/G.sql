--
-- ���� ������������ � ������� SQLiteStudio v3.4.4 � �� ��� 29 14:22:50 2024
--
-- �������������� ��������� ������: System
--
PRAGMA foreign_keys = off;
BEGIN TRANSACTION;

-- �������: CompactDiscs
CREATE TABLE IF NOT EXISTS CompactDiscs (
    Id INTEGER PRIMARY KEY AUTOINCREMENT,
    Title TEXT NOT NULL,
    EnsembleId INTEGER,
    ReleaseDate TEXT,
    Price REAL,
    FOREIGN KEY (EnsembleId) REFERENCES Ensembles(Id)
);
INSERT INTO CompactDiscs (Id, Title, EnsembleId, ReleaseDate, Price) VALUES (1, 'CD 1', 1, '2024-01-01', 15.99);
INSERT INTO CompactDiscs (Id, Title, EnsembleId, ReleaseDate, Price) VALUES (2, 'CD 2', 1, '2024-02-01', 19.99);
INSERT INTO CompactDiscs (Id, Title, EnsembleId, ReleaseDate, Price) VALUES (3, 'CD 3', 2, '2024-03-01', 9.99);
INSERT INTO CompactDiscs (Id, Title, EnsembleId, ReleaseDate, Price) VALUES (4, 'CD 4', 3, '2024-04-01', 12.99);

-- �������: Ensembles
CREATE TABLE IF NOT EXISTS Ensembles (
    Id INTEGER PRIMARY KEY AUTOINCREMENT,
    Name TEXT NOT NULL,
    Description TEXT
);
INSERT INTO Ensembles (Id, Name, Description) VALUES (1, 'Ensemble 1', 'Description for Ensemble 1');
INSERT INTO Ensembles (Id, Name, Description) VALUES (2, 'Ensemble 2', 'Description for Ensemble 2');
INSERT INTO Ensembles (Id, Name, Description) VALUES (3, 'Ensemble 3', 'Description for Ensemble 3');
INSERT INTO Ensembles (Id, Name, Description) VALUES (4, 'Ensemble 1', 'Description for Ensemble 1');
INSERT INTO Ensembles (Id, Name, Description) VALUES (5, 'Ensemble 2', 'Description for Ensemble 2');
INSERT INTO Ensembles (Id, Name, Description) VALUES (6, 'Ensemble 3', 'Description for Ensemble 3');

-- �������: Musicians
CREATE TABLE IF NOT EXISTS Musicians (
    Id INTEGER PRIMARY KEY AUTOINCREMENT,
    Name TEXT NOT NULL,
    Role TEXT NOT NULL,  -- Performer, Composer, Conductor, etc.
    EnsembleId INTEGER,
    FOREIGN KEY (EnsembleId) REFERENCES Ensembles(Id)
);
INSERT INTO Musicians (Id, Name, Role, EnsembleId) VALUES (1, 'Musician 1', 'Performer', 1);
INSERT INTO Musicians (Id, Name, Role, EnsembleId) VALUES (2, 'Musician 2', 'Composer', 1);
INSERT INTO Musicians (Id, Name, Role, EnsembleId) VALUES (3, 'Musician 3', 'Conductor', 2);
INSERT INTO Musicians (Id, Name, Role, EnsembleId) VALUES (4, 'Musician 4', 'Performer', 3);

COMMIT TRANSACTION;
PRAGMA foreign_keys = on;
