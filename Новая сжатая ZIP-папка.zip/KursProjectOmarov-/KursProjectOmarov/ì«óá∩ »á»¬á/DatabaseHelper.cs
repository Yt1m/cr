﻿using System;
using System.Collections.Generic;
using System.Data.SQLite;

namespace KursProjectOmarov
{
    public static class DatabaseHelper
    {
        private static string connectionString = "Data Source=C:/Users/ro697/Desktop/KursProjectOmarov/KursProjectOmarov/G.sql";

        // Получение списка ансамблей
        public static List<string> GetEnsembles()
        {
            var ensembles = new List<string>();
            using (var connection = new SQLiteConnection(connectionString))
            {
                connection.Open();
                string query = "SELECT DISTINCT EnsembleName FROM Ensembles";
                using (var command = new SQLiteCommand(query, connection))
                using (var reader = command.ExecuteReader())
                {
                    while (reader.Read())
                    {
                        ensembles.Add(reader.GetString(0));
                    }
                }
            }
            return ensembles;
        }

        // Количество музыкальных произведений
        public static int GetCompositionCount(string ensembleName)
        {
            int count = 0;
            using (var connection = new SQLiteConnection(connectionString))
            {
                connection.Open();
                string query = "SELECT COUNT(*) FROM Compositions WHERE EnsembleName = @EnsembleName";
                using (var command = new SQLiteCommand(query, connection))
                {
                    command.Parameters.AddWithValue("@EnsembleName", ensembleName);
                    count = Convert.ToInt32(command.ExecuteScalar());
                }
            }
            return count;
        }

        // Названия всех дисков ансамбля
        public static List<string> GetCDTitles(string ensembleName)
        {
            var cdTitles = new List<string>();
            using (var connection = new SQLiteConnection(connectionString))
            {
                connection.Open();
                string query = "SELECT Title FROM CDs WHERE EnsembleName = @EnsembleName";
                using (var command = new SQLiteCommand(query, connection))
                {
                    command.Parameters.AddWithValue("@EnsembleName", ensembleName);
                    using (var reader = command.ExecuteReader())
                    {
                        while (reader.Read())
                        {
                            cdTitles.Add(reader.GetString(0));
                        }
                    }
                }
            }
            return cdTitles;
        }

        // Лидеры продаж текущего года
        public static List<string> GetBestsellers()
        {
            var bestsellers = new List<string>();
            using (var connection = new SQLiteConnection(connectionString))
            {
                connection.Open();
                string query = "SELECT Title FROM Sales WHERE Year = strftime('%Y', 'now') ORDER BY QuantitySold DESC LIMIT 5";
                using (var command = new SQLiteCommand(query, connection))
                using (var reader = command.ExecuteReader())
                {
                    while (reader.Read())
                    {
                        bestsellers.Add(reader.GetString(0));
                    }
                }
            }
            return bestsellers;
        }
    }
}
