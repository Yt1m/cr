﻿using System;
using System.Windows;

namespace KursProjectOmarov
{
    public partial class EditEnsembleWindow : Window
    {
        public EditEnsembleWindow()
        {
            InitializeComponent();
        }

        private void SaveButton_Click(object sender, RoutedEventArgs e)
        {
            string ensembleName = TextBoxEnsemble.Text;
            string leaderName = TextBoxLeader.Text;

            // Логика редактирования ансамбля
            MessageBox.Show($"Ансамбль {ensembleName} обновлен с новым руководителем {leaderName}.");
            this.Close();
        }

        private void CancelButton_Click(object sender, RoutedEventArgs e)
        {
            this.Close();
        }
    }
}
    