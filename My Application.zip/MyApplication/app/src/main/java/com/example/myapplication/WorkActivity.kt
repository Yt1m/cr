package com.example.myapplication

import android.os.Bundle
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity

class WorkActivity : AppCompatActivity() {
    private lateinit var resultText: TextView

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_work)

        resultText = findViewById(R.id.result_text)
        val sharedPreferences = getSharedPreferences("AppData", MODE_PRIVATE)
        val savedWord = sharedPreferences.getString("savedWord", "Нет даных")
        resultText.text = savedWord
    }
}
