package com.example.myapplication

import android.content.SharedPreferences
import android.os.Bundle
import android.widget.Button
import android.widget.EditText
import android.widget.RadioButton
import androidx.appcompat.app.AppCompatActivity

class BeginActivity : AppCompatActivity() {
    private lateinit var inputWord: EditText
    private lateinit var upperCase: RadioButton
    private lateinit var lowerCase: RadioButton
    private lateinit var saveButton: Button
    private lateinit var sharedPreferences: SharedPreferences

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_begin)

        inputWord = findViewById(R.id.input_word)
        upperCase = findViewById(R.id.upper_case)
        lowerCase = findViewById(R.id.lower_case)
        saveButton = findViewById(R.id.save_button)

        sharedPreferences = getSharedPreferences("AppData", MODE_PRIVATE)

        saveButton.setOnClickListener {
            val word = inputWord.text.toString()
            val result = when {
                upperCase.isChecked -> word.uppercase()
                lowerCase.isChecked -> word.lowercase()
                else -> word
            }
            sharedPreferences.edit().putString("savedWord", result).apply()
        }
    }
}
